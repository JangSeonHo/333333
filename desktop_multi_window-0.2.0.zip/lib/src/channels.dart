import 'package:flutter/services.dart';

const multiWindowChannel = MethodChannel('mixin.one/flutter_multi_window');

const windowEventChannel = MethodChannel(
  'mixin.one/flutter_multi_window_channel',
);
